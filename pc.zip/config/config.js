let appConfig = {
    baseIp:"http://aglostech1.yicp.io:9080",
    showMap:true,
    mapIp:"http://aglostech1.yicp.io:9099"
}